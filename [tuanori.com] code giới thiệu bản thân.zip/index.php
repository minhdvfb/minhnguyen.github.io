<!DOCTYPE html>
<html lang="en">
<head>
	    <meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta content='width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0' name='viewport'/>
<meta content='width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=5' name='viewport'/>
    
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="keywords" content="" />
    <meta name="description" content="" />
<meta content='text/html; charset=UTF-8' http-equiv='Content-Type'/>
<meta content='web' name='generator'/>
	<meta http-equiv="X-UA-Compatible" content="Trang web chia sẻ tool tds" />
	<title>TUẤN ORI IT</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	
</head> 
<body>
	<style type="text/css">
        aimg{
            filter: drop-shadow(7px 7px 10px red);
            
        }
		.avatar {
			max-width: 100px;
  height: 100px;
			
			border: 5px solid red;
			border-radius: 50%;
			}
			    .profile-card__name {
				
				color: blue;
	font-size: 30;
	text-align:center;
				}
				.tichxanh {
					height: 100px;
					}

body {
	align-items: center;
}


.fb {
			max-width: 50px;
  height: 50px;
			border: 1px solid blue;
			
			border-radius: 50%;
			}
			fb1{
            filter: drop-shadow(5px 5px 5px blue);
            
        }
        .thong-tin{
        	color: blue;
						
						text-align:center;
						}
						.zalo{
							
			background: #456BD9;
  border: 0.1875em solid blue;
  border-radius: 50%;
  box-shadow: 0.375em 0.375em 0 0 rgba(15, 28, 63, 0.125);
  height: 50px;
  width: 50px;
			}
			zalo1{
				filter: drop-shadow(5px 5px 5px blue);
				}
			.atm{
				justify-content: center;
				text-align:center;
				display: flex;
				}
			</style>
			<div class="body_view container col">
			<div class="display-flex">
			<div class="atm bg-dark">
			<div class="col col-lg-12">
                    <div class="card-body pt-2">
			<div class="view_key">
                      <div class="card card-mini mb-4">
                        <div class="card-body">
			<div class="text-center">
<aimg><img class="avatar" src="https://atplink.com/uploads/avatars/a777113b77c6cf9c28d36348fd25c09f.png" ></aimg>
</div>
<div class='profile-card__name'>TUẤN ORI<img class="tichxanh" src="https://i0.wp.com/s1.uphinh.org/2021/07/21/Tich-xanh.png" data-toggle="tooltip" data-placement="right" title="Đã xác minh" style="width: 30px; height: 30px;">
</div>
<p data-toggle="tooltip" data-placement="top" data-original-title="ATM - TOOL"><span style="border-radius: 5px; background: -webkit-linear-gradient(left, #eb0101, #eb01dd);" class="badge badge-lg badge-danger"><i class="fa fa-user"></i>Admin</span> <span style="color:#1b04f9;background: -webkit-linear-gradient(left, #fffc00, #00ffe4); border-radius: 5px;" class="badge badge-lg badge-light ">Đáng Kính</span> <span style="color:white;background: -webkit-linear-gradient(left, #05e5f9, #eb0101); border-radius: 5px;" class="badge badge-lg badge-light ">Hạng VIP</span> <span style="color:white;background: -webkit-linear-gradient(left, green, green); border-radius: 5px;" class="badge badge-lg badge-light ">Người Kiểm Duyệt</span> <span style="color:white;background: -webkit-linear-gradient(left, #0000bf, #bf00bf); border-radius: 5px;" class="badge badge-lg badge-light ">Người Quản Lý</span> <span style="color:white;background: -webkit-linear-gradient(left, #bf0000, #bfbf00); border-radius: 5px;" class="badge badge-lg badge-light ">Lập Trình Viên</span> <span style="color:white;background: -webkit-linear-gradient(left, red, red); border-radius: 5px;" class="badge badge-lg badge-light ">Premium</span> </p>
<!--cái nút ở trên by keyvip.xyz-->
<div color="black" class="chu"> Tên Thật : PHẠM HOÀNG TUẤN </div><br />
<div color="black" class="chu"> Giới Tính : NAM</div><br />
<div color="black" class="chu"> Nơi Sinh Ra : QUẢNG NGÃI</div><br />
<div color="black" class="chu">Năm Sinh : 2*** </div><br />
<div color="black" class="chu">Sở Thích : VIẾT CODE LÚC RẢNH </div><br />
<h1 color="blue" class="chu1">Thành Tích Của Tôi </h1><br />

<span>
<a class="d-flex justify-content-center" style="text-decoration: none;">Số Dư 1Tháng : 10triệu </a>
<a class="d-flex justify-content-center" style="text-decoration: none;">Facebook : 10K Follow</a>
</span>
<br />
<br />
<h1 class='thong-tin'>Thông Tin Liên Hệ</h1>
<div class="text-center">
<span>
	<a href="https://www.facebook.com/phamhoangtuan.ytb">
<fb1><img class="fb" src="https://sv3.anh365.com/images/2021/10/12/tai-xung.png" ></fb1></a>
<a href="//zalo.me/0812665001">
<zalo1><img class="zalo" src="https://sv3.anh365.com/images/2021/10/12/tai-xung-1.png" ></zalo1></a>
<a href="https://tuanori.com/" >
<fb1><img class="fb" src="https://sv3.anh365.com/images/2021/10/12/images-4.jpg" ></fb1></a>
</span>
</div>
</div>
</div>

                        </div>
                      </div>
                    </div>
                    </div>
                    </div>
                    </div>
                        
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
<!--code by ATM - TOOL-->
</body>
</html>